/**
 * AddressService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC2 Nov 16, 2004 (12:19:44 EST) WSDL2Java emitter.
 */

package com.billsoft.xml.ezgeo;

public interface AddressService extends javax.xml.rpc.Service {
    public java.lang.String getAddressServiceSoapAddress();

    public com.billsoft.xml.ezgeo.AddressServiceSoap getAddressServiceSoap() throws javax.xml.rpc.ServiceException;

    public com.billsoft.xml.ezgeo.AddressServiceSoap getAddressServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
