﻿/**************************************************************************
 **                                                                       *
 ** Copyright 2017 by Avalara, Inc.                                       *
 **   All Rights Reserved. No part of this publication may be reproduced, *
 **   stored in a retrieval system, or transmitted, in any form, by any   *
 **   means, without the prior written permission of the publisher.       *
 **                                                                       *
 **************************************************************************

Description
    UI for Rest Demo Application


 UPDATE HISTORY:
    Ryan Robinson   12/07/2016   Created
*/
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Avalara.TestCommon.Benchmark;
using Avalara.TestCommon.DataSetup;
using System.Configuration;
using Avalara.TestCommon.Common;
using System.Drawing;
using Telerik.WinControls;
using System.Threading;
using Telerik.Charting;
using System.Reflection;
using System.Diagnostics;
using Avalara.CommsPlatform.Api.Models;

namespace Avalara.RestDemoApplication
{
    /// <summary>
    /// Windows form for the AFC SaaS Pro REST Demo application.
    /// </summary>
    public partial class TestingWindow : Form
    {
        public static volatile bool FinishedBenchmark = false;
        string baseAddress = ConfigurationManager.AppSettings["DefaultUrl"];
        private static Thread benchmarkProcess;
        private DateTime benchmarkStartTime;
        public System.Threading.Timer DemoTimer;
        public static bool CancelBenchmark;
        public static bool AbortBenchmark;
        public int MaxTimedTestMins = 5;     // 5 minutes
        public int MaxCountThousands = 100;  // 100,000 count
        public bool DisplayAdvancedTab = false;
        public bool DisplayClock = false;
        public bool DisplayCPUs = false;
        public bool DisplayThroughput = false;
        public bool DisableGraph = false;
        internal DemoStatus DStatus = null;
        public bool StopTimerFlag = false;

        // Constants
        public const int MAX_DATA_POINTS = 1000;
        
        /// <summary>
        /// Constructor.
        /// </summary>
        public TestingWindow()
        {
            InitializeComponent();
            
            UrlLabel.Text = ConfigurationManager.AppSettings["DefaultUrl"];
            UsernameTB.Text = ConfigurationManager.AppSettings["DefaultUsername"];
            PasswordTB.Text = ConfigurationManager.AppSettings["DefaultPassword"];
            ClientIdTB.Text =  ConfigurationManager.AppSettings["ClientId"];
            this.ClientProfileIdTB.Text = ConfigurationManager.AppSettings["ClientProfileId"];
            AvailableCPUsTB.Text = Environment.ProcessorCount.ToString();
            ThreadTrackBar.Value = Environment.ProcessorCount;

            TestCountTB.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            BenchmarkProgressBar.ProgressBarElement.IndicatorElement1.BackColor = Color.FromArgb(255, 100, 0);
            BenchmarkProgressBar.ProgressBarElement.IndicatorElement1.BackColor2 = Color.FromArgb(255, 128, 0);
            BenchmarkProgressBar.ProgressBarElement.IndicatorElement1.BackColor3 = Color.FromArgb(51, 153, 255);
            BenchmarkProgressBar.ProgressBarElement.IndicatorElement1.BackColor4 = Color.FromArgb(0, 0, 255);
            BenchmarkProgressBar.ProgressBarElement.ShowProgressIndicators = true;
            
            ChartData chart = new ChartData(DemoChartView, this);
            ChartData.SetChartConfiguration(
               ConfigurationManager.AppSettings["MinChartXValue"],
               ConfigurationManager.AppSettings["MaxChartXValue"],
               ConfigurationManager.AppSettings["TossOutlierFlag"],
               ConfigurationManager.AppSettings["OutlierUpperBound"],
               ConfigurationManager.AppSettings["OutlierLowerBound"]
               );

            if (!DisplayAdvancedTab)
            {
                DemoTabControl.TabPages.Remove(AdvancedSettingsTab);
            }

            string buff = ConfigurationManager.AppSettings["DisplayClock"];
            if (!string.IsNullOrEmpty(buff)) bool.TryParse(buff, out DisplayClock);
            DemoClock.Visible = DisplayClock;

            buff = ConfigurationManager.AppSettings["DisplayCPUs"];
            if (!string.IsNullOrEmpty(buff)) bool.TryParse(buff, out DisplayCPUs);
            AvailableCPUsLB.Visible = DisplayCPUs;
            AvailableCPUsTB.Visible = DisplayCPUs;

            buff = ConfigurationManager.AppSettings["DisplayThroughput"];
            if (!string.IsNullOrEmpty(buff)) bool.TryParse(buff, out DisplayThroughput);
            ThroughputLB.Visible = DisplayThroughput;
            ThroughputTB.Visible = DisplayThroughput;

            buff = ConfigurationManager.AppSettings["DisableGraph"];
            if (!string.IsNullOrEmpty(buff)) bool.TryParse(buff, out DisableGraph);
            DisabledLB.Visible = DisableGraph;

            buff = ConfigurationManager.AppSettings["MaxThreads"];
            ThreadTrackBar.Minimum = 1;
            int maxThreads = 0;
            if (!string.IsNullOrEmpty(buff))
            {
                if (buff.ToUpper().Contains("CPU"))
                {
                    ThreadTrackBar.Maximum = Environment.ProcessorCount;
                }
                else if (Int32.TryParse(buff, out maxThreads))
                {
                    ThreadTrackBar.Maximum = maxThreads;
                }
            }

            if (ThreadTrackBar.Maximum <= 16)
            {
                ThreadTrackBar.LargeTickFrequency = 1;
            }
            else if (ThreadTrackBar.Maximum <= 32)
            {
                ThreadTrackBar.LargeTickFrequency = 2;
            }
            else if (ThreadTrackBar.Maximum <= 64)
            {
                ThreadTrackBar.LargeTickFrequency = 5;
            }
            else
            {
                ThreadTrackBar.LargeTickFrequency = 10;
            }

            buff = ConfigurationManager.AppSettings["MaxTimedTestMins"];
            if (!string.IsNullOrEmpty(buff)) Int32.TryParse(buff, out MaxTimedTestMins);

            buff = ConfigurationManager.AppSettings["MaxCountThousands"];
            if (!string.IsNullOrEmpty(buff)) Int32.TryParse(buff, out MaxCountThousands);

            //TestCountTB.MaskedEditBoxElement.MouseWheel += new MouseEventHandler(TestCountTB_MouseWheel);
            TestCountTB.MaskedEditBoxElement.EnableMouseWheel = false;
            TimedMinsTB.MaskedEditBoxElement.EnableMouseWheel = false;

            Assembly assembly = Assembly.GetExecutingAssembly();
            FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(assembly.Location);
            this.Text += " " + fvi.ProductVersion;

            SetStatusLabel("Pending");
        }

        /// <summary>
        /// Increments progress bar value.
        /// </summary>
        /// <param name="inc">Increment.</param>
        public void IncrementBenchmarkProgressBar(int inc)
        {
            if (CancelBenchmark) return;

            if (BenchmarkProgressBar.InvokeRequired)
            {
                BenchmarkProgressBar.Invoke(new MethodInvoker(delegate
                {
                    if ((BenchmarkProgressBar.Value1 + inc) >= BenchmarkProgressBar.Maximum)
                    {
                        BenchmarkProgressBar.Value1 = BenchmarkProgressBar.Maximum;
                    }
                    else
                    {
                        BenchmarkProgressBar.Value1 += inc;
                    }
                }));
            }
            else
            {
                if ((BenchmarkProgressBar.Value1 + inc) >= BenchmarkProgressBar.Maximum)
                {
                    BenchmarkProgressBar.Value1 = BenchmarkProgressBar.Maximum;
                }
                else
                {
                    BenchmarkProgressBar.Value1 += inc;
                }
            }
        }

        /// <summary>
        /// Sets the progress bar value.
        /// </summary>
        /// <param name="value"></param>
        public void SetBenchmarkProgressBar(int value)
        {
            if (CancelBenchmark) return;

            if (BenchmarkProgressBar.InvokeRequired)
            {
                BenchmarkProgressBar.Invoke(new MethodInvoker(delegate
                {
                    if (value >= BenchmarkProgressBar.Maximum)
                    {
                        BenchmarkProgressBar.Value1 = BenchmarkProgressBar.Maximum;
                    }
                    else if (value <= BenchmarkProgressBar.Value1)
                    {
                        return;  // Do nothing - do not back up for delayed thread updates
                    }
                    else
                    {
                        BenchmarkProgressBar.Value1 = value;
                    }
                }));
            }
            else
            {
                if (value >= BenchmarkProgressBar.Maximum)
                {
                    BenchmarkProgressBar.Value1 = BenchmarkProgressBar.Maximum;
                }
                else if (value <= BenchmarkProgressBar.Value1)
                {
                    return;  // Do nothing - do not back up for delayed thread updates
                }
                else
                {
                    BenchmarkProgressBar.Value1 = value;
                }
            }
        }

        /// <summary>
        /// Adds a data point to the chart.
        /// </summary>
        /// <param name="x">X-value</param>
        /// <param name="y">Y-value</param>
        public void UpdateChartView(int x, int y)
        {
            if (DemoChartView.InvokeRequired)
            {
                DemoChartView.Invoke(new MethodInvoker(delegate
                {
                    ((Telerik.WinControls.UI.ScatterSeries)DemoChartView.Series[0]).DataPoints.Add(new ScatterDataPoint(x, y));
                }));
            }
            else
            {
                ((Telerik.WinControls.UI.ScatterSeries)DemoChartView.Series[0]).DataPoints.Add(new ScatterDataPoint(x, y));
            }
        }

        /// <summary>
        /// Initializes API stats.
        /// </summary>
        public void InitAPIStats()
        {
            benchmarkStartTime = DateTime.UtcNow;
        }

        /// <summary>
        /// Reset API stats displayed in the UI.
        /// </summary>
        public void ResetAPIStatsForNewBenchmark()
        {
            AvgApiThreadTimeLB.Text = "(pending)";
            ApiCalls.Text = "(pending)";
            TestStartTimeLB.Text = "(pending)";
            TestEndTimeLB.Text = "(pending)";
            ElapsedTimeLB.Text = "(pending)";
            ThroughputTB.Text = "(pending)";
        }

        /// <summary>
        /// Updates API stats
        /// </summary>
        /// <param name="apiCount">API request count.</param>
        /// <param name="totalMillisecs">Total milliseconds for API test run.</param>
        public void UpdateAPIStats(int apiCount, double totalMillisecs)
        {
            double avgThreadTimeSecs = (totalMillisecs / apiCount) / 1000;
            if (AvgApiThreadTimeLB.InvokeRequired)
            {
                AvgApiThreadTimeLB.Invoke(new MethodInvoker(delegate { AvgApiThreadTimeLB.Text = avgThreadTimeSecs.ToString("#.###### secs"); }));
            }
            else
            {
                AvgApiThreadTimeLB.Text = avgThreadTimeSecs.ToString("#.###### secs");
            }

            if (ApiCalls.InvokeRequired)
            {
                ApiCalls.Invoke(new MethodInvoker(delegate { ApiCalls.Text = apiCount.ToString(); }));
            }
            else
            {
                ApiCalls.Text = apiCount.ToString();
            }
        }

        /// <summary>
        /// Sets the time elapsed for the test run.
        /// </summary>
        /// <param name="timespan">Time elapsed.</param>
        public void UpdateElapsedTime(TimeSpan timespan)
        {
            if (ElapsedTimeLB.InvokeRequired)
            {
                ElapsedTimeLB.Invoke(new MethodInvoker(delegate
                {
                    ElapsedTimeLB.Text = string.Format("{0:mm\\.ss\\.fff} mm.ss.fff", timespan);
                }));
            }
            else
            {
                ElapsedTimeLB.Text = string.Format("{0:mm\\.ss\\.fff} mm.ss.fff", timespan);
            }
        }

        /// <summary>
        /// Finalizes API stats.
        /// </summary>
        /// <param name="apiCount">API request count.</param>
        /// <param name="timespan">Time elapsed.</param>
        public void FinalizeAPIStats(int apiCount, TimeSpan timespan)
        {
            UpdateElapsedTime(timespan);

            double throughput = timespan.TotalSeconds / (double)apiCount;
            if (ThroughputTB.InvokeRequired)
            {
                ThroughputTB.Invoke(new MethodInvoker(delegate
                {
                    ThroughputTB.Text = throughput.ToString("##.##### secs/call");
                }));
            }
            else
            {
                ThroughputTB.Text = throughput.ToString("##.##### secs/call");
            }

            if (AbortBenchmark)
            {
                SetStatusLabel("Aborted!");
            }
            else
            {
                SetStatusLabel("Finished!");
            }
        }

        /// <summary>
        /// Sets the start time for the test run.
        /// </summary>
        /// <param name="start">Start time.</param>
        public void SetStartTime(DateTime start)
        {
            if (TestStartTimeLB.InvokeRequired)
            {
                TestStartTimeLB.Invoke(new MethodInvoker(delegate
                {
                    TestStartTimeLB.Text = start.ToLongTimeString();
                }));
            }
            else
            {
                TestStartTimeLB.Text = start.ToLongTimeString();
            }
        }

        /// <summary>
        /// Sets the end time for the test run.
        /// </summary>
        /// <param name="end">End time.</param>
        public void SetEndTime(DateTime end)
        {
            if (TestEndTimeLB.InvokeRequired)
            {
                TestEndTimeLB.Invoke(new MethodInvoker(delegate
                {
                    TestEndTimeLB.Text = end.ToLongTimeString();
                }));
            }
            else
            {
                TestEndTimeLB.Text = end.ToLongTimeString();
            }
        }

        /// <summary>
        /// Returns an object containing the benchmark settings set in the UI.
        /// </summary>
        /// <returns></returns>
        internal BenchmarkSettings GetBenchmarkSettings()
        {
            TestCalculationTypes calcType =
               CalcStandardRB.Checked ? TestCalculationTypes.StdTaxes :
               CalcAdjustmentRB.Checked ? TestCalculationTypes.StdAdjustments :
               CalcTaxInclusiveRB.Checked ? TestCalculationTypes.TaxInclusive :
               CalcTaxInclusiveAdjustmentRB.Checked ? TestCalculationTypes.TaxInclusiveAdjustment :
               ZipLookupRB.Checked ? TestCalculationTypes.ZipLookup :
               TestCalculationTypes.EndOfTestCalculationTypes;

            BenchmarkSettings bs = new BenchmarkSettings(
               TransactionTB.Text,
               ServiceTB.Text,
               ChargeTB.Text,
               InvoiceDate.Value,
               PCodeTB.Text,
               calcType,
               (int)ThreadTrackBar.Value);

            return bs;
        }

        /// <summary>
        /// Posts a sample request to the RET API.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PostSampleBTN_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                TelecomBenchmark process = new TelecomBenchmark();

                int clientId = string.IsNullOrEmpty(ClientIdTB.Text) ? -1 : Convert.ToInt16(ClientIdTB.Text.Trim());
                int clientProfileId = string.IsNullOrEmpty(ClientProfileIdTB.Text) ? -1 : Convert.ToInt16(ClientProfileIdTB.Text.Trim());
                process.RunSingleTransaction(GetBenchmarkSettings()); ;
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }
        
        /// <summary>
        /// Load event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TestingWindow_Load(object sender, EventArgs e)
        {
            // Add winform load time settings here
        }

        /// <summary>
        /// Go button mouse down event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GoButton_MouseDown(object sender, MouseEventArgs e)
        {
            GoButton.Image = Properties.Resources.GoButtonClicked;
        }

        /// <summary>
        /// Go button mouse up event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GoButton_MouseUp(object sender, MouseEventArgs e)
        {
            GoButton.Image = Properties.Resources.GoButtonStd;
        }

        /// <summary>
        /// Posts an API request in order to validate the provided credentials and get the REST version.
        /// </summary>
        /// <param name="restVersion">Output parameter for REST version.</param>
        /// <returns>Boolean indicating success or failure.</returns>
        private bool VerifyCredentials(out string restVersion)
        {
            restVersion = string.Empty;
            VerifyCredentialsErrorMsg.Text = string.Empty;
            int clientId = string.IsNullOrEmpty(ClientIdTB.Text) ? -1 : Convert.ToInt16(ClientIdTB.Text.Trim());
            int clientProfileId = string.IsNullOrEmpty(ClientProfileIdTB.Text) ? -1 : Convert.ToInt16(ClientProfileIdTB.Text.Trim());
            TelecomBenchmark process = new TelecomBenchmark();
            return process.GetRESTVersion(baseAddress, UsernameTB.Text, PasswordTB.Text, clientId, clientProfileId, out restVersion);
        }

        /// <summary>
        /// Verify credentials checkbox event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void VerifyCredentialCheckBox_ToggleStateChanged(object sender, Telerik.WinControls.UI.StateChangedEventArgs args)
        {
            if (!VerifyCredentialCheckBox.Checked)
            {
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor = Color.FromArgb(255, 238, 156, 156);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor2 = Color.FromArgb(255, 255, 0, 0);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor3 = Color.FromArgb(255, 178, 34, 34);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor4 = Color.FromArgb(255, 114, 19, 19);

                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.GradientStyle = GradientStyles.Linear;
                RestVersionLB.Text = "REST API Version: (unverified)";
                return;
            }

            string restVersion = string.Empty;
            bool verified = VerifyCredentials(out restVersion);

            if (verified)
            {
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor = Color.FromArgb(255, 183, 238, 156);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor2 = Color.FromArgb(255, 85, 255, 0);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor3 = Color.FromArgb(255, 82, 178, 34);
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.BackColor4 = Color.FromArgb(255, 51, 114, 19);

                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.Fill.GradientStyle = GradientStyles.Linear;
                VerifyCredentialCheckBox.ButtonElement.CheckMarkPrimitive.CheckElement.ForeColor = Color.DarkBlue;
                RestVersionLB.Text = "REST API Version: " + restVersion;
                return;
            }

            //If it failed reset the state but leave up the error message
            VerifyCredentialsErrorMsg.Text = restVersion;
            VerifyCredentialCheckBox.Checked = false;
        }

        /// <summary>
        /// Joins the current thread to the benchmark process.
        /// </summary>
        public void JoinThread()
        {
            benchmarkProcess.Join(TimeSpan.Zero);
        }

        /// <summary>
        /// Sets the specified text in the status label.
        /// </summary>
        /// <param name="text">Status text.</param>
        public void SetStatusLabel(string text)
        {
            if (StatusLabel.InvokeRequired)
            {
                StatusLabel.Invoke(new MethodInvoker(delegate { StatusLabel.Text = text; }));
            }
            else
            {
                StatusLabel.Text = text;
            }

            if (StatusBGLabel.InvokeRequired)
            {
                StatusBGLabel.Invoke(new MethodInvoker(delegate { StatusBGLabel.Text = text; }));
            }
            else
            {
                StatusBGLabel.Text = text;
            }
        }

        /// <summary>
        /// Go button click event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GoButton_Click(object sender, EventArgs e)
        {
            string restVersion = string.Empty;
            if (!VerifyCredentials(out restVersion))
            {
                MessageBox.Show("Credentials not valid.  Please update and verify before running test.",
                         "Invalid Credentials", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FinishedBenchmark = false;
            AbortBenchmark = false;
            ResetAPIStatsForNewBenchmark();

            TestTypes tt = (CountTestTypeRB.IsChecked) ? TestTypes.COUNT_TEST : TestTypes.TIMED_TEST;

            int tstval = 0;
            List<CalcTaxesRequest> transList = null;
            int progressBarMaximum = 0;
            switch (tt)
            {
                case TestTypes.COUNT_TEST:
                    tstval = string.IsNullOrEmpty(TestCountTB.Text) ? 0 : int.Parse(TestCountTB.Text) * 1000;
                    if (tstval <= 0)
                    {
                        MessageBox.Show("Test count must be set and > 0 for the selected test type.",
                           "Test Count Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    progressBarMaximum = tstval;
                    break;
                case TestTypes.TIMED_TEST:
                    tstval = string.IsNullOrEmpty(TimedMinsTB.Text) ? 0 : int.Parse(TimedMinsTB.Text) * 60;
                    if (tstval <= 0)
                    {
                        MessageBox.Show("Test minutes must be set and > 0 for the selected test type.",
                           "Test Minutes Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    progressBarMaximum = tstval; // Test time in seconds
                    break;
            }

            BenchmarkSettings settings = GetBenchmarkSettings();
            settings.Status = DStatus = new DemoStatus(this, tt, tstval);
            settings.Transactions = transList;
            settings.Status.DemoChart = new ChartData(DemoChartView, this);

            BenchmarkProgressBar.Value1 = 0;
            BenchmarkProgressBar.Maximum = progressBarMaximum;
            SetStatusLabel("In Progress ...");

            DemoTabControl.SelectedTab = DemoMetricsTab;

            int? clientId = null;
            int? profileId = null;

            try
            {
                clientId = int.Parse(ClientIdTB.Text);
            }
            catch { }

            try
            {
                profileId = int.Parse(ClientProfileIdTB.Text);
            }
            catch { }
            
            settings.BaseAddress = baseAddress;
            settings.UserName = UsernameTB.Text;
            settings.Password = PasswordTB.Text;
            settings.ClientId = clientId;
            settings.ProfileId = profileId;

            try
            {
                benchmarkProcess = new Thread(new ParameterizedThreadStart(TelecomBenchmark.ProcessRequestAsThread));
                benchmarkProcess.Start((object)settings);
            }
            catch (Exception ex)
            {
                if (!CancelBenchmark)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        
        /// <summary>
        /// Test count text box event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TestCountTB_ValueChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TimedMinsTB.Text))
            {
                return;
            }

            if (MaxCountThousands < int.Parse(TestCountTB.Text))
            {
                MessageBox.Show(string.Format("Test value of {0}K exceeded max API Calls {1}K - value set to max.  Update config setting \"MaxCountThousands\" to change the limit.",
                   TestCountTB.Text, MaxCountThousands));
                TestCountTB.Value = MaxCountThousands;
            }
            CountTestTypeRB.IsChecked = true;
        }

        /// <summary>
        /// Timed test text box event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TimedMinsTB_ValueChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TimedMinsTB.Text))
            {
                return;
            }

            if (MaxTimedTestMins < int.Parse(TimedMinsTB.Text))
            {
                MessageBox.Show(string.Format("Test value of {0} exceed max minutes {1} - value set to max.  Update config setting \"MaxTimedTestMins\" to change the limit.",
                   TimedMinsTB.Text, MaxTimedTestMins));
                TimedMinsTB.Value = MaxTimedTestMins;
            }
            TimedTestTypeRB.IsChecked = true;
        }

        /// <summary>
        /// Form closing event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TestingWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            CancelBenchmark = true;
            if (DStatus != null) DStatus.EndTimedDemo();
        }

        /// <summary>
        /// Thread track bar event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ThreadTrackBar_ValueChanged(object sender, EventArgs e)
        {
            if (ThreadTrackBar.Value == 0)
            {
                ThreadTrackBar.Value = 1;
            }
        }

        /// <summary>
        /// Abort button event handler.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AbortButton_Click(object sender, EventArgs e)
        {
            if (DStatus != null)
            {
                AbortBenchmark = true;
                DStatus.EndTimedDemo();
            }
        }
    }
}
