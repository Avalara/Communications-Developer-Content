﻿using Avalara.CommsPlatform.Api.Models;
using Avalara.RestDemoApplication;
using Avalara.TestCommon.Common;
using System;
using System.Collections.Generic;

namespace Avalara.TestCommon.Benchmark
{
    /// <summary>
    /// Benchmark settings.
    /// </summary>
    public class BenchmarkSettings
    {
        public const int MAX_GENERATED_TEST_COUNT = 50000;
        public const int MAX_TEST_COUNT = 100000;
        public const int MS_TO_NS = 1000000;
        
        public short DefaultTransactionType;
        public short DefaultServiceType;
        public double DefaultCharge;
        public DateTime DefaultInvoiceDate;
        public uint DefaultPCode;
        public string BaseAddress;
        public string UserName;
        public string Password;
        public int? ClientId;
        public int? ProfileId;

        public TestCalculationTypes CalcType;
        public int Threads;

        public List<CalcTaxesRequest> Transactions = null;
        public int TestRange = 0;
        public DemoStatus Status = null;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="transactionType">Default transaction type.</param>
        /// <param name="serviceType">Default service type.</param>
        /// <param name="charge">Default charge.</param>
        /// <param name="date">Default date.</param>
        /// <param name="pcode">Default PCode.</param>
        /// <param name="calcType">Default calculation type.</param>
        /// <param name="threads">Number of threads.</param>
        public BenchmarkSettings(
           string transactionType,
           string serviceType,
           string charge,
           DateTime date,
           string pcode,
           TestCalculationTypes calcType,
           int threads)
        {
            if (!short.TryParse(transactionType, out DefaultTransactionType))
            {
                throw new Exception(string.Format("Default transaction type {0} is not valid short value", transactionType));
            }
            if (!short.TryParse(serviceType, out DefaultServiceType))
            {
                throw new Exception(string.Format("Default service type {0} is not valid short value", serviceType));
            }
            if (!double.TryParse(charge, out DefaultCharge))
            {
                throw new Exception(string.Format("Default charge {0} is not valid double value", charge));
            }
            DefaultInvoiceDate = date;
            if (!uint.TryParse(pcode, out DefaultPCode))
            {
                throw new Exception(string.Format("Default pcode {0} is not valid unsigned int value", pcode));
            }
            CalcType = calcType;
            Threads = threads;
        }
    }
}