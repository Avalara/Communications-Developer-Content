﻿/**************************************************************************
 **                                                                       *
 ** Copyright 2017 by Avalara, Inc.                                       *
 **   All Rights Reserved. No part of this publication may be reproduced, *
 **   stored in a retrieval system, or transmitted, in any form, by any   *
 **   means, without the prior written permission of the publisher.       *
 **                                                                       *
 **************************************************************************

Description
    EnumeratedTypes for Rest Demo Application


 UPDATE HISTORY:
    Ryan Robinson   12/07/2016   Created
*/

namespace Avalara.TestCommon.Common
{
    /// <summary>
    /// Test calculation Type.
    /// </summary>
    public enum TestCalculationTypes
    {
        StdTaxes,
        StdAdjustments,
        TaxInclusive,
        TaxInclusiveAdjustment,
        ZipLookup,
        EndOfTestCalculationTypes
    }

    /// <summary>
    /// Test types.
    /// </summary>
    public enum TestTypes
    {
        TIMED_TEST,
        COUNT_TEST
    }

    /// <summary>
    /// Types of jurisdiction input.
    /// </summary>
    public enum JurisdictionTypes
    {
        PCode,
        Address,
        Fips,
        Npanxx,
        Invalid
    }

    /// <summary>
    /// Request types.
    /// </summary>
    public enum RequestTypes
    {
        CalcTaxes,
        CalcAdj,
        CalcRev,
        CalcRevAdj,
        ZipLookup,
        End
    }
}
