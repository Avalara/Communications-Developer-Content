﻿using Avalara.TestCommon.DataSetup;
using System;
using System.Collections.Generic;
using Avalara.TestCommon.Common;

namespace Avalara.RestDemoApplication
{
    /// <summary>
    /// Class used to contain status for a demo run.
    /// </summary>
    public class DemoStatus
    {
        private const int LARGEST_TICK_STEP = 100;
        private const int DEFAULT_TIMER_INTERVAL_MILLISECONDS = 1000;
        private const int TIMER_DUETIME_MILLISECONDS = 1000;

        //Retrieved from benchmark
        public TimeSpan DemoTimeSpan;   // Total time span of all API calls
        public int DemoAPICalls;        // Count of API calls
        public List<double> AvgSecsPerCall;
        public int DataPointSpan;      // Number of calls to summarize to remain within MaxDataPoints limit

        //Passed into benchmark
        public TestTypes TestType;
        public int TimedTestSeconds;
        public DateTime DemoEndTime;
        public DateTime DemoStartTime;
        public int CountTestNumber;
        public int FileTestTransactions;
        public int MaxValue;
        public TestingWindow TestWin;

        internal int SmallTick = -1;
        internal int LargeTick = -1;

        public int TimerIntervalMilliseconds;
        private readonly object _threadLock = new object();

        public ChartData DemoChart = null;

        /// <summary>
        /// Returns the maximum number of transactions or seconds for processing.
        /// </summary>
        /// <returns></returns>
        public int GetTransactionCount()
        {
            int tcnt = 0;
            switch (TestType)
            {
                case TestTypes.COUNT_TEST:
                    tcnt = CountTestNumber;
                    break;
                case TestTypes.TIMED_TEST:
                    tcnt = TimedTestSeconds;
                    break;
            }

            return tcnt;
        }

        /// <summary>
        /// Helper method.
        /// </summary>
        public void ResetTicks()
        {
            SmallTick = -1;
            LargeTick = -1;
        }

        /// <summary>
        /// Helper method.
        /// </summary>
        /// <param name="threads"></param>
        /// <param name="idx"></param>
        public void SetTicks(int threads, int idx)
        {
            if (LargeTick < LARGEST_TICK_STEP)
            {
                int tick = 0;
                if (idx > 25000) tick = LARGEST_TICK_STEP;
                else if (idx > 10000) tick = 50;
                else if (idx > 2500) tick = 25;
                else if (idx > 1000) tick = 10;
                else if (idx > 500) tick = 8;
                else if (idx > 250) tick = 5;
                else if (idx > 100) tick = 4;
                else tick = 2;

                LargeTick = tick + (int)(tick * ((double)threads / 4.0));
                SmallTick = (int)((double)LargeTick / 4.0) + 1;
            }
        }

        /// <summary>
        /// Helper method.
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public bool TestSmallTick(int idx)
        {
            return (idx % SmallTick == 0);
        }

        /// <summary>
        /// Helper method.
        /// </summary>
        /// <param name="idx"></param>
        /// <returns></returns>
        public bool TestLargeTick(int idx)
        {
            return (idx % LargeTick == 0);
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="testingWindow">Test window.</param>
        /// <param name="tt">Test type.</param>
        /// <param name="val">Maximum value in seconds or request count.</param>
        public DemoStatus(TestingWindow testingWindow, TestTypes tt, int val)
        {
            ResetTicks();
            DemoTimeSpan = new TimeSpan();
            TestWin = testingWindow;
            TestType = tt;
            MaxValue = val;
            TimerIntervalMilliseconds = DEFAULT_TIMER_INTERVAL_MILLISECONDS;

            switch (tt)
            {
                case TestTypes.COUNT_TEST:
                    CountTestNumber = MaxValue;
                    break;
                case TestTypes.TIMED_TEST:
                    TimedTestSeconds = MaxValue;
                    break;
            }
        }

        /// <summary>
        /// Starts the timer.
        /// </summary>
        /// <param name="intervalMilliseconds"></param>
        public void StartTimer(int intervalMilliseconds)
        {
            DemoStartTime = DateTime.UtcNow;
            TestWin.StopTimerFlag = false;
            if ((TestType == TestTypes.TIMED_TEST) && (TimedTestSeconds > 0))
            {
                DemoEndTime = DemoStartTime.AddSeconds(TimedTestSeconds);
            }
            if (intervalMilliseconds > 0) TimerIntervalMilliseconds = intervalMilliseconds;
            TestWin.DemoTimer = new System.Threading.Timer(OnTimedEvent, null, TIMER_DUETIME_MILLISECONDS, TimerIntervalMilliseconds);
        }

        /// <summary>
        /// Stops the timer.
        /// </summary>
        public void StopTimer()
        {
            TestWin.StopTimerFlag = true;  // Disable timed event processing (OnTimedEvent) before disposing timer
            try
            {
                if (TestWin.DemoTimer != null)
                {
                    TestWin.DemoTimer.Dispose();
                    TestWin.DemoTimer = null;
                }
            }
            catch
            {
                TestWin.DemoTimer = null;
            }
        }

        /// <summary>
        /// Finalizes the demo run.
        /// </summary>
        public void EndTimedDemo()
        {
            TestingWindow.FinishedBenchmark = true;
            TestWin.DStatus = null;
            StopTimer();
        }

        /// <summary>
        /// Event handler for timer tick event.
        /// </summary>
        /// <param name="source"></param>
        public void OnTimedEvent(object source)
        {
            if (!TestWin.StopTimerFlag)
            {
                if (TestWin.DemoTimer == null)
                {
                    EndTimedDemo();
                    Console.WriteLine("Timer killed before its time ...");
                }
                else
                {
                    // Specify what you want to happen when the Elapsed event is raised.
                    TimeSpan realTimeSpan = DateTime.UtcNow - DemoStartTime;
                    if (TestType == TestTypes.TIMED_TEST)
                    {
                        TestWin.SetBenchmarkProgressBar((int)realTimeSpan.TotalSeconds);
                    }
                    TestWin.UpdateElapsedTime(realTimeSpan);

                    if ((TestType == TestTypes.TIMED_TEST) && (DateTime.UtcNow > DemoEndTime))
                    {
                        EndTimedDemo();
                    }
                }
            }
        }
    }
}