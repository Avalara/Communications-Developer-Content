﻿/**************************************************************************
 **                                                                       *
 ** Copyright 2017 by Avalara, Inc.                                       *
 **   All Rights Reserved. No part of this publication may be reproduced, *
 **   stored in a retrieval system, or transmitted, in any form, by any   *
 **   means, without the prior written permission of the publisher.       *
 **                                                                       *
 **************************************************************************

Description
    Benchmark methods Rest Demo Application processing


 UPDATE HISTORY:
    Ryan Robinson   12/07/2016   Created
*/
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using Avalara.TestCommon.Common;
using System.IO;
using System.Threading;
using static Avalara.RestDemoApplication.TestingWindow;
using System.Diagnostics;
using Avalara.TestCommon.DataSetup;
using Avalara.RestDemoApplication;
using Avalara.CommsPlatform.Api.Models;
using System.Linq;
using Avalara.CommsPlatform.Api.Client;
using System.Configuration;

namespace Avalara.TestCommon.Benchmark
{
    /// <summary>
    /// Telecom benchmark processing.
    /// </summary>
    public class TelecomBenchmark
    {
        internal static CalcTaxesRequest TransactionItem = null;
        internal static Random rnd = new Random(DateTime.Now.Millisecond);

        /// <summary>
        /// Constructor.
        /// </summary>
        public TelecomBenchmark()
        {
            TransactionItem = GetTransaction(0, 0, 0, DateTime.Today, 100.0);
        }

        /// <summary>
        /// Posts a request to the REST API to obtain the REST version.
        /// </summary>
        /// <param name="url">Base URL for REST API.</param>
        /// <param name="userName">User name for API authentication.</param>
        /// <param name="password">Password for API authentication.</param>
        /// <param name="clientId">Comms Platform Client ID.</param>
        /// <param name="profileId">Client profile ID.</param>
        /// <returns></returns>
        public bool GetRESTVersion(string url, string userName, string password, int? clientId, int? profileId, out string result)
        {
            try
            {
                using (var client = new AfcRestClient(url, userName, password, clientId, profileId))
                {
                    var task = client.GetAsync($"api/v1/Application/RESTVersion");
                    result = task.Result;
                }
            }
            catch (Exception ex)
            {
                result = ex.Message;
                return false;
            }

            return true;
        }

        /// <summary>
        /// Creates an object for the tax calculation API request body.
        /// </summary>
        /// <param name="documentCode">Value to use for the invoice's document code.</param>
        /// <param name="settings">Benchmark settings.</param>
        /// <returns></returns>
        internal static CalcTaxesRequest GetTransaction(int documentCode, BenchmarkSettings settings)
        {
            CalcTaxesRequest t = null;

            switch (settings.Status.TestType)
            {
                case TestTypes.COUNT_TEST:
                case TestTypes.TIMED_TEST:
                    t = TransactionItem;
                    Invoice invoice = t.Invoices.First();
                    InputCannedData.TSPair tspair = InputCannedData.TSPairs[rnd.Next(InputCannedData.TSPairs.Count - 1)];
                    invoice.BillTo = new Location { PCode = InputCannedData.PCodes[rnd.Next(InputCannedData.PCodes.Count - 1)] };
                    LineItem item = invoice.Items.First();
                    item.TransactionType = (short)tspair.TransType;
                    item.ServiceType = (short)tspair.ServiceType;
                    invoice.DocumentCode = documentCode.ToString();
                    break;
            }

            return t;
        }

        /// <summary>Processes sample telecom transaction using AFC SaaS Pro Rest tax calculation call .</summary>
        /// <param name="settings">Settings to be used for tax calculation / benchmark</param>
        /// <returns>String with tax data or exception message (as applicable)</returns>
        public string RunSingleTransaction(BenchmarkSettings settings)
        {
            string ResultText = string.Empty;
            try
            {
                var trans = GetTransaction(settings.DefaultPCode, settings.DefaultTransactionType, settings.DefaultServiceType,
                   settings.DefaultInvoiceDate, settings.DefaultCharge);

                using (var client = new AfcRestClient(settings.BaseAddress, settings.UserName, settings.Password, settings.ClientId, settings.ProfileId))
                {
                    var response = client.CalcTaxes(trans).Result;
                }
            }
            catch (Exception ex)
            {
                ResultText = ex.Message;
            }

            return ResultText;
        }

        // Test routine for calibrating tick logic for update of graph and run time fields
        static void TestTicks(DemoStatus stat)
        {
            for (int threads = 1; threads < 100; threads *= 2)
            {
                stat.ResetTicks();
                stat.SetTicks(threads, 100);
                stat.SetTicks(threads, 1000);
                stat.SetTicks(threads, 5000);
                stat.SetTicks(threads, 10000);
                stat.SetTicks(threads, 20000);
                stat.SetTicks(threads, 50000);
                stat.SetTicks(threads, 250000);
            }
        }

        /// <summary>Processes telecom transactions using AFC SaaS Pro Rest tax calculation calls for gathering performance statistics.</summary>
        /// <param name="settings">Settings to be used for tax calculation / benchmark</param>
        /// <returns>String with overall summarized benchmark metrics for run</returns>
        public static int RunBenchmark(BenchmarkSettings settings)
        {
            List<CalcTaxesRequest> transactionList = settings.Transactions;
            int transactionCount = settings.Status.GetTransactionCount();
            TestTypes tt = settings.Status.TestType;
            if (tt == TestTypes.TIMED_TEST)
            {
                transactionCount = Int32.MaxValue;
            }

            // Load configuration options
            var opts = new ParallelOptions { MaxDegreeOfParallelism = settings.Threads };

            CallStats.CallType apiCallType = CallStats.CallType.TaxCalculation;

            switch (settings.CalcType)
            {
                case TestCalculationTypes.StdAdjustments:
                    transactionList.ForEach(t => t.Invoices.First().Items.First().IsAdjustment = true);
                    apiCallType = CallStats.CallType.TaxAdjustment;
                    break;
                case TestCalculationTypes.TaxInclusive:
                    transactionList.ForEach(t => t.Invoices.First().Items.First().TaxInclusive = true);
                    apiCallType = CallStats.CallType.TaxInclusiveCalculation;
                    break;
                case TestCalculationTypes.TaxInclusiveAdjustment:
                    transactionList.ForEach(t => t.Invoices.First().Items.First().IsAdjustment = true);
                    transactionList.ForEach(t => t.Invoices.First().Items.First().TaxInclusive = true);
                    apiCallType = CallStats.CallType.TaxInclusiveAdjustment;
                    break;
            }

            double totApiTimeMillisecs = 0.0;
            var startRealTime = DateTime.UtcNow;
            settings.Status.TestWin.SetStartTime(startRealTime);
            settings.Status.TestWin.InitAPIStats();
            settings.Status.StartTimer(0);
            settings.Status.ResetTicks();

            int transactionsProcessed = 0;

            using (var client = new AfcRestClient(settings.BaseAddress, settings.UserName, settings.Password, settings.ClientId, settings.ProfileId))
            {
                Parallel.For(0, transactionCount, opts, (idx, loopState) =>
                {
                    if (TestingWindow.CancelBenchmark) { loopState.Stop(); return; }
                    if (TestingWindow.FinishedBenchmark) { loopState.Stop(); }

                    CalcTaxesRequest request = GetTransaction(transactionsProcessed, settings);
                    Invoice invoice = request.Invoices.First();
                    LineItem item = invoice.Items.First();

                    switch (apiCallType)
                    {
                        case CallStats.CallType.TaxCalculation:
                            item.TaxInclusive = false;
                            item.IsAdjustment = false;
                            break;
                        case CallStats.CallType.TaxAdjustment:
                            item.TaxInclusive = false;
                            item.IsAdjustment = true;
                            break;
                        case CallStats.CallType.TaxInclusiveCalculation:
                            item.TaxInclusive = true;
                            item.IsAdjustment = false;
                            break;
                        case CallStats.CallType.TaxInclusiveAdjustment:
                            item.TaxInclusive = true;
                            item.IsAdjustment = true;
                            break;
                    }

                    transactionsProcessed++;
                    Stopwatch apiStopWatch = new Stopwatch();
                    try
                    {
                        int numOfTaxes = 0;
                        apiStopWatch.Start();
                        var response = client.CalcTaxes(request).Result;
                        apiStopWatch.Stop();
                        numOfTaxes = response.InvoiceResults?.First().ItemResults?.First().Taxes?.Count() ?? 0;

                        if (TestingWindow.CancelBenchmark) { loopState.Stop(); return; }
                        if (TestingWindow.FinishedBenchmark) { loopState.Stop(); }

                        settings.Status.DemoTimeSpan += apiStopWatch.Elapsed;
                        totApiTimeMillisecs += apiStopWatch.ElapsedMilliseconds;

                        if (tt != TestTypes.TIMED_TEST)
                        {
                            settings.Status.TestWin.IncrementBenchmarkProgressBar(1);
                        }

                        settings.Status.SetTicks(settings.Threads, transactionsProcessed);
                        if (settings.Status.TestSmallTick(transactionsProcessed))
                        {
                            settings.Status.TestWin.UpdateAPIStats(transactionsProcessed, totApiTimeMillisecs);
                        }

                        if (settings.Status.TestLargeTick(transactionsProcessed))
                        {
                            settings.Status.DemoChart.AddChartPoint(transactionsProcessed, (int)apiStopWatch.Elapsed.TotalMilliseconds);
                        }

                    }
                    catch (Exception)
                    {
                        if (TestingWindow.CancelBenchmark) { loopState.Stop(); return; }
                        var end = DateTime.Now;

                        if (tt != TestTypes.TIMED_TEST)
                            settings.Status.TestWin.IncrementBenchmarkProgressBar(1);
                    } // end catch
                }); // end Parallel.For loop
            }

            if (settings.Status.TestType != TestTypes.TIMED_TEST)
            {
                if (tt != TestTypes.TIMED_TEST)
                    settings.Status.TestWin.IncrementBenchmarkProgressBar(1);
            }
            else
            {
                transactionCount = transactionsProcessed;
            }
            settings.Status.EndTimedDemo();
            settings.Status.TestWin.UpdateAPIStats(transactionCount, totApiTimeMillisecs);
            settings.Status.TestWin.JoinThread();
            var endRealTime = DateTime.UtcNow;
            settings.Status.TestWin.SetEndTime(endRealTime);
            TimeSpan realTimeSpan = endRealTime - startRealTime;
            settings.Status.TestWin.FinalizeAPIStats(transactionCount, realTimeSpan);
            return transactionCount;
        }

        /// <summary>
        /// Returns a list of requests containing random data.
        /// </summary>
        /// <param name="count">Number of requests to create.</param>
        /// <returns></returns>
        public static List<CalcTaxesRequest> GetRandomTransactions(int count)
        {
            List<CalcTaxesRequest> list = new List<CalcTaxesRequest>();

            if (count <= 0) count = BenchmarkSettings.MAX_GENERATED_TEST_COUNT;

            Random rnd = new Random(count);
            int maxPCode = InputCannedData.PCodes.Count - 1;
            int maxTSPair = InputCannedData.TSPairs.Count - 1;

            CalcTaxesRequest t = GetTransaction(0, 0, 0, DateTime.Today, 100.0);
            Invoice invoice = t.Invoices.First();
            LineItem item = invoice.Items.First();

            for (int idx = 0; idx < count; idx++)
            {
                uint pcode = InputCannedData.PCodes[rnd.Next(maxPCode)];
                InputCannedData.TSPair tspair = InputCannedData.TSPairs[rnd.Next(maxTSPair)];
                invoice.BillTo = new Location { PCode = pcode };
                item.TransactionType = (short)tspair.TransType;
                item.ServiceType = (short)tspair.ServiceType;
                invoice.DocumentCode = idx.ToString();
                list.Add(t);
            }

            return list;
        }

        /// <summary>
        /// Creates a Transaction object.
        /// </summary>
        /// <param name="pcode">PCode.</param>
        /// <param name="trans">Transaction ID.</param>
        /// <param name="serv">Service ID.</param>
        /// <returns></returns>
        public static CalcTaxesRequest GetTransaction(uint pcode, short trans, short serv, DateTime transDate, double charge)
        {
            var item = new LineItem
            {
                AdjustmentMethod = 0,
                Charge = charge,
                Debit = false,
                Lines = 1,
                Locations = 1,
                Minutes = 10,
                SaleType = 1,
                TransactionType = trans,
                ServiceType = serv
            };

            var invoice = new Invoice
            {
                BillTo = new Location { PCode = pcode },
                CustomerType = 0,
                Date = transDate,
                Lifeline = false,
                Items = new[] { item }
            };

            var request = new CalcTaxesRequest
            {
                CompanyData = new CompanyData
                {
                    BusinessClass = 1,
                    Facilities = false,
                    Franchise = false,
                    Regulated = true,
                    ServiceClass = 0
                },
                Invoices = new[] { invoice }
            };

            return request;
        }

        /// <summary>
        /// Runs the benchmark process.
        /// </summary>
        /// <param name="p">BenchmarkSettings object.</param>
        public static void ProcessRequestAsThread(object p)
        {
            try
            {
                BenchmarkSettings settings = (BenchmarkSettings)p;
                int apiCallCount = RunBenchmark(settings);
                settings.Status.EndTimedDemo();
            }
            catch
            {
                if ((!CancelBenchmark) && (!AbortBenchmark))
                {
                    throw;
                }
            }
        }
    }
}
